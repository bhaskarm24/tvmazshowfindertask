export const BREAKPOINTS = {
  small: '425px',
  medium: '768px',
  large: '1024px',
};

