export { default } from './errorPage';
