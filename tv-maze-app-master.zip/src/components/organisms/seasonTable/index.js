export { default } from './seasonTable';
