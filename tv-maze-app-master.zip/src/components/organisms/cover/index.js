export { default } from './cover';
