import React from 'react';

const ErrorPage = () => {
  return (
    <div data-cy="error-page">Something is wrong!</div>
  );
};

export default ErrorPage;
