export class CoverImage {
  medium = '';
  original = '';
}

